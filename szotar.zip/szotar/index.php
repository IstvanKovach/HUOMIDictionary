<!DOCTYPE html>
<html lang="hu">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Matematikai értelmező szótár</title>
    <!-- Link a CSS stíluslapodhoz -->
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <!-- Fejléc -->
    <header>
        <h1>Matematikai értelmező szótár</h1>
    </header>

    <!-- Menü -->
    <nav>
        <ul>
            <li><a href="index.php">Kezdőlap</a></li>
            <li><a href="dictionary.php">Szótár</a></li>
            <!-- Egyéb menüpontok -->
        </ul>
    </nav>

    <!-- Tartalom -->
    <main>
        <!-- Ide jöhet a dinamikus tartalom, például PHP változók, adatbázis lekérdezések stb. -->
    </main>

    <!-- Lábléc -->
    <footer>
        <p>&copy; 2024 Matematikai értelmező szótár</p>
    </footer>

    <!-- JavaScript fájl hivatkozás -->
    <script src="script.js"></script>
</body>
</html>
