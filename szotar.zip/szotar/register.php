<!DOCTYPE html>
<html lang="hu">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Regisztráció</title>
    <style>
        body {
            font-family: 'Arial', sans-serif;
            background-color: #f4f4f4;
            margin: 0;
            display: flex;
            align-items: center;
            justify-content: center;
            height: 100vh;
        }

        form {
            background-color: #ffffff;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            padding: 20px;
            width: 300px;
        }

        label {
            display: block;
            margin-bottom: 8px;
            font-weight: bold;
        }

        input {
            width: 100%;
            padding: 8px;
            margin-bottom: 16px;
            border: 1px solid #ccc;
            border-radius: 4px;
            box-sizing: border-box;
        }

        button {
            background-color: #4caf50;
            color: white;
            padding: 10px;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            width: 100%;
        }

        button:hover {
            background-color: #45a049;
        }

        .switch-page {
            margin-top: 20px;
            text-align: center;
        }

        .switch-page a {
            text-decoration: none;
            color: #007bff;
        }
    </style>
</head>
<body>

    <div class="container">
        <form method="post" action="register_process.php">
            <h2>Regisztráció</h2>
            <label for="username">Felhasználónév:</label>
            <input type="text" id="username" name="username" required>

            <label for="password">Jelszó:</label>
            <input type="password" id="password" name="password" required>

            <label for="confirm_password">Jelszó megerősítése:</label>
            <input type="password" id="confirm_password" name="confirm_password" required>

            <button type="submit">Regisztráció</button>
        </form>

        <div class="switch-page">
            <p>Már van fiókod? <a href="login.php">Bejelentkezés</a></p>
        </div>
    </div>

</body>
</html>
