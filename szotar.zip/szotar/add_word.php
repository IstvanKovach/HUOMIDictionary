<?php
session_start();
include 'db_connection.php';

// Ellenőrizze, hogy a felhasználó be van-e jelentkezve és admin-e
if (!isset($_SESSION['user_id']) || $_SESSION['szerep'] !== 'admin') {
    header("Location: login.php");
    exit();
}


if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $newSzo = $conn->real_escape_string($_POST['newSzo']);
    $newJelentes = $conn->real_escape_string($_POST['newJelentes']);
    $newJelentes2 = $conn->real_escape_string($_POST['newJelentes2']);


    if (empty($newSzo) || empty($newJelentes) || empty($newJelentes2)) {
        die("Minden mező kitöltése kötelező.");
    }

    $insertQuery = "INSERT INTO szotar (szo, jelentes, jelentes2) VALUES ('$newSzo', '$newJelentes', '$newJelentes2')";

    if ($conn->query($insertQuery) === TRUE) {
        header("Location: dictionary.php");
        exit();
    } else {
        die("Hiba a szó hozzáadása során: " . $conn->error);
    }
}

$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Szó hozzáadása</title>
    <!-- Bootstrap CSS -->
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            margin: 0;
            padding: 0;
            text-align: center;
        }
        .container {
            max-width: 800px;
            margin: 0 auto;
            padding: 20px;
            background-color: #fff;
            border-radius: 10px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }
        h2, h3 {
            color: #333;
        }
        input, textarea {
            width: 100%;
            margin-bottom: 10px;
            padding: 12px;
            box-sizing: border-box;
        }
        button {
            background-color: #009FFF;
            color: white;
            padding: 10px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
        }
        button:hover {
            background-color: #007BFF;
        }
    </style>
</head>
<body>

    <!-- Navigációs sáv -->
    <nav class="navbar navbar-expand-lg navbar-light bg-light">
        <a class="navbar-brand" href="index.php">Szótár</a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav ml-auto">
                <li class="nav-item">
                    <a class="nav-link" href="dictionary.php">Vissza a szótárhoz</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="logout.php">Kijelentkezés</a>
                </li>
            </ul>
        </div>
    </nav>

    <div class="container mt-5">
    <title>Szó hozzáadása</title>
    <!-- Bootstrap CSS -->
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            margin: 0;
            padding: 0;
            text-align: center;
        }
        .container {
            max-width: 800px;
            margin: 20px auto;
            padding: 20px;
            background-color: #fff;
            border-radius: 10px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }
        h2 {
            color: #333;
            margin-bottom: 20px;
        }
        input, textarea {
            width: 100%;
            margin-bottom: 10px;
            padding: 12px;
            box-sizing: border-box;
        }
        button {
            background-color: #009FFF;
            color: white;
            padding: 10px 20px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
        }
        button:hover {
            background-color: #007BFF;
        }
    </style>
</head>
<body>

    <!-- Navigációs sáv -->
    <nav class="navbar navbar-expand-lg navbar-light bg-light">
        <div class="container">
            <a class="navbar-brand" href="index.php">Szótár</a>
            <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav ml-auto">
                    <li class="nav-item">
                        <a class="nav-link" href="dictionary.php">Vissza a szótárhoz</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="logout.php">Kijelentkezés</a>
                    </li>
                </ul>
            </div>
        </div>
    </nav>

    <div class="container">
        <h2>Szó hozzáadása</h2>

        <form method="post" action="">
            <div class="form-group">
                <label for="newSzo">Magyarul:</label>
                <input type="text" id="newSzo" name="newSzo" class="form-control" required>
            </div>

            <div class="form-group">
                <label for="newJelentes">Ukránul:</label>
                <input type="text" id="newJelentes" name="newJelentes" class="form-control" required>
            </div>

            <div class="form-group">
                <label for="newJelentes2">Bővebb információ:</label>
                <textarea id="newJelentes2" name="newJelentes2" class="form-control" rows="4"></textarea>
            </div>

            <button type="submit" class="btn btn-primary">Hozzáadás</button>
        </form>

        <p><a href="dictionary.php">Vissza a szótárhoz</a></p>
    </div>

    <!-- Bootstrap JS és szükséges függőségek -->
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.2/dist/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>
</html>