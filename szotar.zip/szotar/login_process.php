<?php
session_start();
include 'db_connection.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $username = $_POST['username'];
    $password = $_POST['password'];

    $sql = "SELECT * FROM felhasznalok WHERE username = '$username' AND password = '$password'";
    $result = $conn->query($sql);

    if ($result->num_rows == 1) {
        // Sikeres bejelentkezés
        $row = $result->fetch_assoc();
        $_SESSION['user_id'] = $row['id'];
        $_SESSION['username'] = $row['username'];
        $_SESSION['szerep'] = $row['szerep'];
        
        header("Location: dictionary.php");
        exit();
    } else {
        // Sikertelen bejelentkezés
        echo "Sikertelen bejelentkezés. Hibás felhasználónév vagy jelszó.";
    }
}

$conn->close();
?>
