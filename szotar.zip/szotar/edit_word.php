<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Szó szerkesztése</title>
    <link rel="stylesheet" href="style.css">
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            margin: 0;
            padding: 0;
            text-align: center;
        }
        .container {
            max-width: 800px;
            margin: 0 auto;
            padding: 20px;
            background-color: #fff;
            border-radius: 10px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }
        h2, h3 {
            color: #333;
        }
        input, textarea {
            width: 100%;
            margin-bottom: 10px;
            padding: 20px;
            box-sizing: border-box;
        }
        iframe {
            width: 100%;
            height: 500px;
            border: 1px solid #ddd;
        }
        button {
            background-color: #009FFF;
            color: white;
            padding: 10px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
        }
        button:hover {
            background-color: #009FFF;
        }
    </style>
</head>
<body>
<nav class="navbar navbar-expand-lg navbar-light bg-light">
        <div class="container">
            <a class="navbar-brand" href="index.php">Szótár</a>
            <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav ml-auto">
                    <li class="nav-item">
                        <a class="nav-link" href="dictionary.php">Vissza a szótárhoz</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="logout.php">Kijelentkezés</a>
                    </li>
                </ul>
            </div>
        </div>
    </nav>   
    <div class="container">
        <?php
        session_start();
        include 'db_connection.php';

        if (!isset($_SESSION['user_id']) || $_SESSION['szerep'] !== 'admin') {
            header("Location: login.php");
            exit();
        }

        if (!isset($_GET['id'])) {
            header("Location: dictionary.php");
            exit();
        }

        $id = $_GET['id'];

        $query = "SELECT * FROM szotar WHERE szo_id = $id";
        $result = $conn->query($query);

        if (!$result || $result->num_rows !== 1) {
            die("Hiba a lekérdezésben vagy a szó nem található.");
        }

        $row = $result->fetch_assoc();

        if ($_SERVER["REQUEST_METHOD"] == "POST") {
            $newSzo = $_POST['newSzo'];
            $newJelentes = $_POST['newJelentes'];
            $newJelentes2 = $_POST['newJelentes2'];
            $newLink = $_POST['newLink'];

            $updateQuery = "UPDATE szotar SET szo = '$newSzo', jelentes = '$newJelentes', jelentes2 = '$newJelentes2', link = '$newLink' WHERE szo_id = $id";

            if ($conn->query($updateQuery) === TRUE) {
                header("Location: dictionary.php");
                exit();
            } else {
                die("Hiba a frissítés során: " . $conn->error);
            }
        }

        $conn->close();
        ?>

        <h2>Szó szerkesztése: <?php echo $row['szo']; ?></h2>

        <form method="post" action="">
            <div class="form-group">
                <label for="newSzo">Magyar:</label>
                <input type="text" id="newSzo" name="newSzo" class="form-control" value="<?php echo $row['szo']; ?>" required>
            </div>

            <div class="form-group">
                <label for="newJelentes">Ukrán:</label>
                <input type="text" id="newJelentes" name="newJelentes" class="form-control" value="<?php echo $row['jelentes']; ?>" required>
            </div>

            <div class="form-group">
                <label for="newJelentes2">Bővebb információ:</label>
                <textarea id="newJelentes2" name="newJelentes2" class="form-control"><?php echo $row['jelentes2']; ?></textarea>
            </div>

            <div class="form-group">
                <label for="newLink">Link:</label>
                <input type="text" id="newLink" name="newLink" class="form-control" value="<?php echo $row['link']; ?>">
            </div>

            <button type="submit" class="btn btn-primary">Mentés</button>
        </form>

        <p><a href="dictionary.php">Vissza a szótárhoz</a></p>
    </div>

    <!-- Bootstrap JS és szükséges függőségek -->
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.2/dist/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>
</html>
