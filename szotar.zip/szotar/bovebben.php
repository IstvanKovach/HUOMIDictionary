<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Szó részletei</title>
    <style>
        body {
            text-align: justify;
            line-height: 1.5;
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            margin: 0;
            padding: 0;
        }
        .container {
            max-width: 600px;
            margin: 20px auto;
            padding: 20px;
            background-color: #fff;
            border-radius: 10px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }
        h2, h3 {
            color: #333;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }
        th, td {
            padding: 8px;
            text-align: left;
            border-bottom: 1px solid #ddd;
        }
        p.back-link {
            position: absolute;
            top: 10px;
            right: 10px;
        }
        p.back-link a {
            text-decoration: none;
            color: #007bff;
        }
        .link-box {
            margin: 20px 0;
            padding: 10px;
            border: 1px solid #ddd;
            background-color: #f9f9f9;
            border-radius: 5px;
        }
        .link-box a {
            color: #007bff;
            text-decoration: none;
        }
        .link-box a:hover {
            text-decoration: underline;
        }
    </style>
</head>
<body>
    <p class="back-link"><a href="dictionary.php">Vissza a szótárhoz</a></p>

    <div class="container">
        <?php
        session_start();
        include 'db_connection.php';

        if (!isset($_SESSION['user_id'])) {
            header("Location: login.php");
            exit();
        }

        if (!isset($_GET['id'])) {
            die("Hibás szó azonosító.");
        }

        $id = $_GET['id'];

        $query = "SELECT * FROM szotar WHERE szo_id = $id";
        $result = $conn->query($query);

        if (!$result) {
            die("Hiba a lekérdezésben: " . $conn->error);
        }

        if ($result->num_rows > 0) {
            while ($row = $result->fetch_assoc()) {
                echo "<h2>Magyarul: " . $row['szo'] . "</h2>";
                echo "<h3>Ukránul: " . $row['jelentes'] . "</h3>";
                echo "<div style='margin: 20px 0; text-align: justify;'>";
                echo "<table>";
                echo "<tr><th>Bővebben:</th></tr>";

                // Szöveg tördelése új sorokon bizonyos karakterek után
                $jelentes2 = wordwrap($row['jelentes2'], 80, "<br>");

                echo "<tr><td>{$jelentes2}</td></tr>";
                echo "</table>";
                echo "</div>";

                // Link doboz
                if (!empty($row['link'])) {
                    echo "<div class='link-box'><a href='" . $row['link'] . "' target='_blank'>További információ</a></div>";
                }
            }
        } else {
            echo "Nincs ilyen szó az adatbázisban.";
        }

        $conn->close();
        ?>
    </div>
</body>
</html>
