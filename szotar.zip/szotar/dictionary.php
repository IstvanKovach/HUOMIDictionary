<?php
session_start();
include 'db_connection.php';

// Ellenőrizze, hogy a felhasználó be van-e jelentkezve
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

// Ellenőrizze, hogy az admin be van-e jelentkezve
$isAdmin = isset($_SESSION['szerep']) && $_SESSION['szerep'] == 'admin';

// Törölési művelet
if ($isAdmin && isset($_GET['delete_id'])) {
    $delete_id = $_GET['delete_id'];
    $deleteQuery = "DELETE FROM szotar WHERE szo_id = $delete_id";
    $conn->query($deleteQuery);
    header("Location: dictionary.php");
    exit();
}

// Oldalazás
$szavakPerPage = 20;
$current_page = isset($_GET['page']) ? $_GET['page'] : 1;
$offset = ($current_page - 1) * $szavakPerPage;

// Alap lekérdezés, ABC sorrendben vagy fordítva
$orderBy = isset($_SESSION['order']) && $_SESSION['order'] == 'desc' ? ' DESC' : ' ASC';

// Ha a "Fordítás csere" gombra kattintottak
if (isset($_POST['swapColumns'])) {
    // Fordítás csere a szűrt eredményekre az oldalzás figyelembevételével
    $swapQuery = "SELECT szo_id, jelentes AS szo, szo AS jelentes, jelentes2 FROM szotar ORDER BY szo$orderBy LIMIT $offset, $szavakPerPage";
    $result = $conn->query($swapQuery);
    if (!$result) {
        die("Hiba a lekérdezésben: " . $conn->error);
    }
} else {
    // Alap lekérdezés ABC sorrendben vagy fordítva, az oldalazással
    $query = "SELECT szo_id, szo, jelentes, jelentes2 FROM szotar ORDER BY szo$orderBy LIMIT $offset, $szavakPerPage";
    $result = $conn->query($query);
    if (!$result) {
        die("Hiba a lekérdezésben: " . $conn->error);
    }
}

// Fetch total number of words for pagination
$totalWordsQuery = "SELECT COUNT(*) as total FROM szotar";
$totalResult = $conn->query($totalWordsQuery);
$totalWords = $totalResult->fetch_assoc()['total'];
$totalPages = ceil($totalWords / $szavakPerPage);

// Ha van ABC sorrend beállítás
if (isset($_GET['order']) && !isset($_POST['swapColumns'])) {
    $_SESSION['order'] = $_GET['order']; // Mentjük az aktuális sorrend beállítást a munkamenetben
    header("Location: dictionary.php");
    exit();
}

// Ellenőrizzük, hogy van-e mentett sorrend beállítás a munkamenetben
if (isset($_SESSION['order']) && $_SESSION['order'] == 'desc') {
    $current_order = 'desc';
    $order_label = 'asc';
} else {
    $current_order = 'asc';
    $order_label = 'desc';
}

// Keresés kezelése
$searchTerm = isset($_GET['search']) ? $_GET['search'] : '';
$searchCondition = "";
if (!empty($searchTerm)) {
    $searchTerm = $conn->real_escape_string($searchTerm);
    $searchCondition = " WHERE szo LIKE '%$searchTerm%' OR jelentes LIKE '%$searchTerm%' OR jelentes2 LIKE '%$searchTerm%'";
}

$query = "SELECT szo_id, szo, jelentes, jelentes2 FROM szotar" . $searchCondition . " ORDER BY szo$orderBy LIMIT $offset, $szavakPerPage";
$result = $conn->query($query);
if (!$result) {
    die("Hiba a lekérdezésben: " . $conn->error);
}
$totalWordsQuery = "SELECT COUNT(*) as total FROM szotar" . $searchCondition;
$totalResult = $conn->query($totalWordsQuery);
$totalWords = $totalResult->fetch_assoc()['total'];
$totalPages = ceil($totalWords / $szavakPerPage);


?>




<!DOCTYPE html>
<html lang="hu">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Szótár</title>
    <!-- Bootstrap CSS -->
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
    <!-- Bootstrap JS és függőségek -->
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.2/dist/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>

    <nav class="navbar navbar-expand-lg navbar-light bg-light">
        <a class="navbar-brand" href="index.php">Szótár</a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav ml-auto">
                <li class="nav-item">
                    <a class="nav-link" href="dictionary.php">Kezdőlap</a>
                </li>
                <?php if ($isAdmin): ?>
                    <li class="nav-item">
                        <a class="nav-link" href="add_word.php">Szó hozzáadása</a>
                    </li>
                <?php endif; ?>
                <li class="nav-item">
                    <a class="nav-link" href="logout.php">Kijelentkezés</a>
                </li>
            </ul>
        </div>
    </nav>

    <div class="container mt-5">
        <h1>Magyar-ukrán online matematikai értelmező szótár</h1>

        <!-- ABC sorrendbe rendezés gombja -->
        <form method="get" action="">
            <button type="submit" class="btn btn-secondary mb-2">Rendezés A-Z</button>
            <input type="hidden" name="order" value="<?php echo $order_label; ?>">
        </form>

        <!-- Keresési űrlap -->
        <form method="get" action="" class="form-inline mb-2">
            <input type="text" class="form-control mr-2" name="search" placeholder="Keresés...">
            <button type="submit" class="btn btn-primary">Keresés</button>
        </form>

        <?php
        if ($result->num_rows > 0) {
            echo "<table class='table'>";
            echo "<thead class='thead-light'><tr><th>Magyar</th><th>Ukrán</th><th>Bővebb információ</th>";
            if ($isAdmin) {
                echo "<th>Műveletek</th>";
            }
            echo "</tr></thead>";
            echo "<tbody>";

            while ($row = $result->fetch_assoc()) {
                echo "<tr>";
                echo "<td>{$row['szo']}</td>";
                echo "<td>{$row['jelentes']}</td>";

                // Ellenőrizze, hogy a "Jelentés2" hosszabb-e 30 karakternél
                if (strlen($row['jelentes2']) > 30) {
                    $shortJelentes2 = substr($row['jelentes2'], 0, 30) . "...";
                    echo "<td>{$shortJelentes2} <a href='bovebben.php?id={$row['szo_id']}'>Bővebben</a></td>";
                } else {
                    echo "<td>{$row['jelentes2']}</td>";
                }

                if ($isAdmin) {
                    echo "<td><a href='edit_word.php?id={$row['szo_id']}'>Szerkesztés</a> | ";
                    echo "<a href='dictionary.php?delete_id={$row['szo_id']}' onclick=\"return confirm('Biztosan törölni szeretnéd ezt a szót?');\">Törlés</a> | ";
                    echo "<a href='bovebben.php?id={$row['szo_id']}'>Bővebben</a></td>";
                } else {
                    echo "<td><a href='bovebben.php?id={$row['szo_id']}'>Bővebben</a></td>";
                }

                echo "</tr>";
            }
            echo "</tbody>";
            echo "</table>";


            
            // Oldalazás gombok
            echo "<div>";
            for ($i = 1; $i <= $totalPages; $i++) {
                echo "<a href='dictionary.php?page=$i" . (isset($_GET['order']) ? "&order={$order_label}" : "") . "' class='btn btn-primary'>$i</a> ";
            }
            echo "</div>";
        } else {
            echo "A szótár üres.";
        }
        ?>
    </div>
</body>
</html>


<?php
$conn->close();
?>
