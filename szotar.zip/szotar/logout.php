<?php
session_start();

// Munkamenet lezárása
session_unset();
session_destroy();

// Átirányítás a bejelentkezési oldalra
header("Location: login.php");
exit();
?>
