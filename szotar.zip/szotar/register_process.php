<?php
include 'db_connection.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $username = $_POST['username'];
    $password = $_POST['password'];

    // Ellenőrizze, hogy a felhasználónév egyedi-e
    $check_username = "SELECT * FROM felhasznalok WHERE username = '$username'";
    $result = $conn->query($check_username);
    

    if ($result->num_rows > 0) {
        echo "A megadott felhasználónév már foglalt.";
    } else {
        // Regisztráció
        $sql = "INSERT INTO felhasznalok (username, password, szerep) VALUES ('$username', '$password', 'felhasznalo')";
        if ($conn->query($sql) === TRUE) {
            echo "Sikeres regisztráció!";
            header("Location: index.php");
            exit();

        } else {
            echo "Hiba a regisztráció során: " . $conn->error;
        }
    }
    $adminUsername = 'admin';  // Az admin felhasználóneve

if ($username === $adminUsername) {
    $sql = "INSERT INTO felhasznalok (felhasznalonev, jelszo, szerep) VALUES ('$username', '$password', 'admin')";
} else {
    $sql = "INSERT INTO felhasznalok (felhasznalonev, jelszo, szerep) VALUES ('$username', '$password', 'felhasznalo')";
}
}
$conn->close();
?>