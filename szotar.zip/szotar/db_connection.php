<?php
$servername = "localhost";
$username = "felhasznalo";
$password = "jelszo";
$dbname = "szotar_db";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Sikertelen kapcsolódás az adatbázishoz: " . $conn->connect_error);
}
?>
